PROBLEM STATEMENT 

Basic Image classifier CNN - Avenger Based.


MY APPROACH

I googled about some basic image classifier on the net and understood some basics of the same. I bought a course on udemy on ML for the task. 
I read about CNN and how the whole thing works. I built a basic model consisting of only two classifications to get a grip over the topic. I went thorugh a medium blog about image classifier cnn using keras.
I further started to analyse datasets in Kaggle and found out about Image Classifier cnn using keras and understood the code from there. I got a basic dataset from a github resource for further understanding. 
I started to build a basic neural net at first with the information gathered. I got an accuracy of 40%. I further asked Databyte members about the increasing the accuracy. He gave me a brief idea about the same.
I started to understand about Image Augmentation, hyperparameters(batch_size,epochs) and addition of more images to make by dataset as large as possible. I also found that adding more layers increased my accuracy to a good extent.
Taking all into consideration, starting with 40%, I moved slowly to 50%, 53.56% and then towards 60%. Digging deeper into understanding the basics and adding more Convolution layers of different filters, with God's grace, I was able to bring the accuracy to 
75%. I was happy considering for the fact that this is the first time I was trying ML and I could push myself this far. Thanks to Databyte Members for the constant advice in this process. 
Hope to strengthen on this new skill which I have loved to practice till I master it.

TOOLS USED

Anaconda (Spyder), Keras, tensorflow, kaggle dataset.

CONCLUSION

Accuracy of the CNN is 75%. Images and snapshot attached. 